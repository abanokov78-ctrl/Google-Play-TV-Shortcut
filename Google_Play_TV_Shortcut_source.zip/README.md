# Google Play TV Shortcut

This small Android app exposes a Leanback launcher entry and explicitly opens:
`com.android.vending/.AssetBrowserActivity`.

## Build without Android Studio
1. Create a new **public or private GitHub repository**.
2. Upload the contents of this folder (not the folder itself) to the repository.
3. Open **Actions** and run **Build Android APK** (or push to `main`).
4. Open the completed workflow run, download the `Google-Play-TV-Shortcut` artifact.
5. Unzip it; install `app-debug.apk` on the Android TV box.

The app does not include Google Play and does not need package-search permission. It sends an explicit intent to the already-installed Play Store.

If Aero TV still does not show it, the launcher may be filtering apps independently of the standard Leanback category.
