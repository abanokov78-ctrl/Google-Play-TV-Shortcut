package com.example.playstoretvshortcut;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Intent launch = new Intent();
            launch.setComponent(new ComponentName(
                "com.android.vending",
                "com.android.vending.AssetBrowserActivity"
            ));
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) {
            Toast.makeText(this,
                "Не удалось открыть Google Play. Проверьте установку магазина.",
                Toast.LENGTH_LONG).show();
        }
        finish();
    }
}
